version 0.1.0 First realise of the library. 
version 0.2.0 Paralelisation of several functions in the code. 
version 0.3.0 Modification of the code to decompose the perturbation of the Sea level.
version 0.3.1 New love number importation based on love numbers calculated by ALMA3
version 0.3.2 Output function added as a csv writer for using in other application
version 0.3.3 Add of the sediment import as in the matlab code
version 0.3.4 Revision of the code to calculate the ground motion at the end of the computation
version 0.3.5 Integration of saving and loading data from previous run